$(function(){
	vaCenter();
	$(window).resize(function(){
		vaCenter();
	});
});

function vaCenter(){
	var winH = $(window).height();
	var winW = $(window).innerWidth();
	var cont = $('#container');
	cont.css("margin-top", (winH - cont.height())/2);
	console.log(winW);	
	if(winW <= 1024)
	{
		cont.css("margin-top", 0);
	}
}